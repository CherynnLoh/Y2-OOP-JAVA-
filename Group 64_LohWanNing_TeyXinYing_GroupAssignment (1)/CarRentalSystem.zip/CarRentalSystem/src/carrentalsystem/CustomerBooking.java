/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalsystem;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author txy20
 */
public class CustomerBooking {

    String OrderID;
    String CusID;
    String CarModel;
    String CarPlate;
    String CarType;
    String RentalDate;
    String RentalDuration;
    String RentalOverdue;
    String Amount;
    String Status;
    String PaymentMethod;
    String BookingConfirmation;
    String RentalFee;

    public CustomerBooking(String OID, String CID, String CModel, String CPlate, String CType,
            String RDate, String RDuration, String ROverdue, String Amount, String Status, String Payment, String Booking) {
        //OID = OrderID;
        OrderID = OID;
        CusID = CID;
        CarModel = CModel;
        CarPlate = CPlate;
        CarType = CType;
        RentalDate = RDate;
        RentalDuration = RDuration;
        RentalOverdue = ROverdue;
        this.Amount = Amount;
        this.Status = Status;
        PaymentMethod = Payment;
        BookingConfirmation = Booking;

    }
    
    public CustomerBooking(String CPlate, String CModel, String CType, String RentalFee, String Status) {
        CarPlate = CPlate;
        CarModel = CModel;
        CarType = CType;
        this.RentalFee = RentalFee;
        this.Status = Status;
    }

    public static String autoincrement() throws FileNotFoundException, IOException {
        String newid = "";
        ArrayList<String> userlist = new ArrayList<>();
        userlist = User.userList();

        String lastid = userlist.get(userlist.size() - 1);
        String[] iddata = lastid.strip().split(",");
        String oldid = iddata[0];
        String id = oldid.substring(3, 7);
        int oldintid = Integer.parseInt(id);
        int nextid = oldintid + 1;
        String strnextid = Integer.toString(nextid);

        switch (strnextid.length()) {
            case 1:
                newid = "OD000" + strnextid;
                break;
            case 2:
                newid = "OD00" + strnextid;
                break;
            case 3:
                newid = "OD0" + strnextid;
                break;
            case 4:
                newid = "OD" + strnextid;
                break;
            default:
                break;
        }
        return newid;
    }

    public CustomerBooking() {
        
    }

    public String getRentalFee() {
        return RentalFee;
    }

    public void setRentalFee(String RentalFee) {
        this.RentalFee = RentalFee;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public String getCusID() {
        return CusID;
    }

    public void setCusID(String CusID) {
        this.CusID = CusID;
    }

    public String getCarModel() {
        return CarModel;
    }

    public void setCarModel(String CarModel) {
        this.CarModel = CarModel;
    }

    public String getCarPlate() {
        return CarPlate;
    }

    public void setCarPlate(String CarPlate) {
        this.CarPlate = CarPlate;
    }

    public String getCarType() {
        return CarType;
    }

    public void setCarType(String CarType) {
        this.CarType = CarType;
    }

    public String getRentalDate() {
        return RentalDate;
    }

    public void setRentalDate(String RentalDate) {
        this.RentalDate = RentalDate;
    }

    public String getRentalDuration() {
        return RentalDuration;
    }

    public void setRentalDuration(String RentalDuration) {
        this.RentalDuration = RentalDuration;
    }

    public String getRentalOverdue() {
        return RentalOverdue;
    }

    public void setRentalOverdue(String RentalOverdue) {
        this.RentalOverdue = RentalOverdue;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String Amount) {
        this.Amount = Amount;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

    public String getBookingConfirmation() {
        return BookingConfirmation;
    }

    public void setBookingConfirmation(String BookingConfirmation) {
        this.BookingConfirmation = BookingConfirmation;
    }

}
