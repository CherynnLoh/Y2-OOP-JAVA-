/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalsystem;

/**
 *
 * @author txy20
 */
public class Car {

    String OrderID;
    String CusID;
    String CarModel;
    String CarPlate;
    String CarType;
    String RentalDate;
    String RentalDuration;
    String RentalOverdue;
    String Amount;
    String Status;
    String PaymentMethod;
    String BookingConfirmation;

    public Car(String OID, String CID, String CModel, String CPlate, String CType,
            String RDate, String RDuration, String ROverdue, String Amount, String Status, String Payment, String Booking) {
        //OID = OrderID;
        OrderID = OID;
        CusID = CID;
        CarModel = CModel;
        CarPlate = CPlate;
        CarType = CType;
        RentalDate = RDate;
        RentalDuration = RDuration;
        RentalOverdue = ROverdue;
        this.Amount = Amount;
        this.Status = Status;
        PaymentMethod = Payment;
        BookingConfirmation = Booking;

    }

    public Car() {

    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String OrderID) {
        this.OrderID = OrderID;
    }

    public String getCusID() {
        return CusID;
    }

    public void setCusID(String CusID) {
        this.CusID = CusID;
    }

    public String getCarModel() {
        return CarModel;
    }

    public void setCarModel(String CarModel) {
        this.CarModel = CarModel;
    }

    public String getCarPlate() {
        return CarPlate;
    }

    public void setCarPlate(String CarPlate) {
        this.CarPlate = CarPlate;
    }

    public String getCarType() {
        return CarType;
    }

    public void setCarType(String CarType) {
        this.CarType = CarType;
    }

    public String getRentalDate() {
        return RentalDate;
    }

    public void setRentalDate(String RentalDate) {
        this.RentalDate = RentalDate;
    }

    public String getRentalDuration() {
        return RentalDuration;
    }

    public void setRentalDuration(String RentalDuration) {
        this.RentalDuration = RentalDuration;
    }

    public String getRentalOverdue() {
        return RentalOverdue;
    }

    public void setRentalOverdue(String RentalOverdue) {
        this.RentalOverdue = RentalOverdue;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String Amount) {
        this.Amount = Amount;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

    public String getBookingConfirmation() {
        return BookingConfirmation;
    }

    public void setBookingConfirmation(String BookingConfirmation) {
        this.BookingConfirmation = BookingConfirmation;
    }

}
