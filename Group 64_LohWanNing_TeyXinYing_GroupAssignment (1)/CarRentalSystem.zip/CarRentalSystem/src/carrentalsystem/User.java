/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author txy20
 */
public class User {

    private static String id;
    private static String Username;
    private static String password;
    private static String name;
    private static String gender;
    private static String contactNum;
    private static String email;
    private static String address;
    File f = new File("\\C:\\Users\\txy20\\Desktop\\uni\\Degree Year 2 (Sem1)\\Object Oriented Development with Java\\Assignment\\CarRentalSystem\\src\\carrentalsystem\\User.txt");

    public User() {

    }

    public User(String u, String p) {
        Username = u;
        password = p;

    }

    public User(String u) {
        Username = u;
    }

    public User(String id, String u, String p, String n, String g, String c, String e, String a) {
        this.id = id;
        Username = u;
        password = p;
        name = n;
        gender = g;
        contactNum = c;
        email = e;
        address = a;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        this.Username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContactNum() {
        return contactNum;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public static ArrayList userList() throws FileNotFoundException, IOException {
        File f = new File("\\C:\\Users\\txy20\\Desktop\\uni\\Degree Year 2 (Sem1)\\Object Oriented Development with Java\\Assignment\\CarRentalSystem\\src\\carrentalsystem\\User.txt");
        BufferedReader br = new BufferedReader(new FileReader(f));
        ArrayList<String> userlist = new ArrayList<String>();
        String lineread = null;
        while ((lineread = br.readLine()) != null) {
            userlist.add(lineread);
        }
        br.close();
        return userlist;
    }

    public static String autoincrement() throws FileNotFoundException, IOException {
        String newid = "";
        ArrayList<String> userlist = new ArrayList<>();
        userlist = User.userList();

        String lastid = userlist.get(userlist.size() - 1);
        String[] iddata = lastid.strip().split(",");
        String oldid = iddata[0];
        String id = oldid.substring(3, 7);
        int oldintid = Integer.parseInt(id);
        int nextid = oldintid + 1;
        String strnextid = Integer.toString(nextid);

        switch (strnextid.length()) {
            case 1:
                newid = "CUS000" + strnextid;
                break;
            case 2:
                newid = "CUS00" + strnextid;
                break;
            case 3:
                newid = "CUS0" + strnextid;
                break;
            case 4:
                newid = "CUS" + strnextid;
                break;
            default:
                break;
        }
        return newid;
    }

    public void editProfile(String password, String contact, String email, String address) throws IOException {
        //Read file into ArrayList
        ArrayList<String> userlist = new ArrayList<>();
//        System.out.println(password);
//        System.out.println(contact);
//        System.out.println(email);
//        System.out.println(address);
        userlist = User.userList();
        //Loop array 
        for (int i = 0; i < userlist.size(); i++) {
            String oneuser = userlist.get(i);
            String[] eachdata = oneuser.split(":");
//            System.out.println(eachdata[1]);
//            System.out.println(Username);
            // Find carplate == txtCarplate
            if (eachdata[1].equals(Username)) {

                String data = eachdata[0] + ":" + eachdata[1] + ":" + password + ":" + eachdata[3] + ":" + eachdata[4] + ":" + contact + ":" + email + ":" + address;
                userlist.set(i, data);
            }

            try ( FileWriter fw = new FileWriter(f)) {
                for (String str : userlist) {
                    fw.write(str + System.lineSeparator());
                }
            }

        }
    }

}
