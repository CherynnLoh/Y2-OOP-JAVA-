/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package car.rental.swing;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DropMode;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;

public class ComboBoxDesign<E> extends JComboBox<E> {
    
    private String labelText = "Default";
    private Color lineColor = new Color(3, 155, 216);
    private boolean mouseOver;
    private int borderTop = 5;
    private int borderLeft = 15;
    private int borderBottom = 5;
    private int borderRight = 15;
    private Color backgroundColor;
    private String fontName = "Century Gothic";
    private int fontSize = 16;
    private boolean cursorChange = true;
    
    public ComboBoxDesign() {
        setBackground(new Color(255, 255, 255, 0)); //Remove background
        setOpaque(false);
        setBorder(new EmptyBorder(borderTop, borderLeft, borderBottom, borderRight));
        setFont(new Font(fontName, 0, fontSize));
        
        //Create and check if mouse is over button
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent me) {
                if(cursorChange == true) {
                    if(checkMouseOver(me.getPoint())) {
                        setCursor(new Cursor(Cursor.HAND_CURSOR));
                    }
                }
            }
        });
        
        setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> jlist, Object o, int i, boolean bln, boolean bln1) {
                Component com = super.getListCellRendererComponent(jlist, o, i, bln, bln1);
                setBorder(new EmptyBorder(5, 5, 5, 5));
                if (bln) {
                    com.setBackground(new Color(255, 154, 64));
                } else {
                    com.setBackground(new Color(255, 255, 255));
                }
                return com;
            }
        });
    }
    
    public String getLabelText() {
        return labelText;
    }

    public void setLabelText(String labeText) {
        this.labelText = labeText;
    }

    public Color getLineColor() {
        return lineColor;
    }

    public void setLineColor(Color lineColor) {
        this.lineColor = lineColor;
    }
    
    public int getBorderTop() {
        return borderTop;
    }
    
    public void setBorderTop(int borderTop) {
        this.borderTop = borderTop;
    }
    
    public int getBorderLeft() {
        return borderLeft;
    }
    
    public void setBorderLeft(int borderLeft) {
        this.borderLeft = borderLeft;
    }
    
    public int getBorderBottom() {
        return borderBottom;
    }
    
    public void setBorderBottom(int borderBottom) {
        this.borderBottom = borderBottom;
    }
    
    public int getBorderRight() {
        return borderRight;
    }
    
    public void setBorderRight(int borderRight) {
        this.borderRight = borderRight;
    }
    
    public Color getBackgroundColor() {
        return backgroundColor;
    }
    
    public void setBackgroundColor(Color backgroundColor) {
        this.backgroundColor = backgroundColor;
    }
    
    public String getFontName() {
        return fontName;
    }
    
    public void setFontName(String fontName) {
        this.fontName = fontName;
    }
    
    public int getFontSize() {
        return fontSize;
    }
    
    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }
    
    public boolean getCursorChange() {
        return cursorChange;
    }
    
    public void setCursorChange(boolean cursorChange) {
        this.cursorChange = cursorChange;
    }
    
    @Override
    protected void paintComponent(Graphics grphcs) {
        int width = getWidth();
        int height = getHeight();
        Graphics2D g2 = (Graphics2D) grphcs;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); //Smooth line
        backgroundColor = new Color(232, 232, 232);
        g2.setColor(backgroundColor);
        g2.fillRoundRect(0, 0, width, height, height, height);
        super.paintComponent(grphcs);
    }
    
    private boolean checkMouseOver(Point mouse) {
        int width = getWidth();
        int height = getHeight();
        Point point = new Point();
        Ellipse2D.Double circle = new Ellipse2D.Double(point.x, point.y, width, height);
        return circle.contains(mouse);
    }
}
