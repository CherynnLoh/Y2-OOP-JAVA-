/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrentalswing;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.GradientPaint;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionAdapter;
import java.awt.Point;
import java.awt.Cursor;
import java.awt.geom.Ellipse2D;
import java.awt.Insets;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;
import java.awt.Color;
import javax.swing.SwingUtilities;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

public class ButtonDesign extends JButton {
    
    private final int round = 30;
    private int top = 10;
    private int left = 10;
    private int bottom = 10;
    private int right = 10;
    private int fontSize = 14;
    private int r = 204;
    private int g = 204;
    private int b = 255;
    private boolean cursorChange = true;
    
    public ButtonDesign() {
        setContentAreaFilled(false);
        setOpaque(false);
        setBorder(new EmptyBorder(top, left, bottom, right));
        setFont(new java.awt.Font("Century Gothic", Font.BOLD, fontSize));
        
        //Create and check if mouse is over button
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent me) {
                if(checkMouseOver(me.getPoint())) {
                    if(cursorChange == true) {
                        setCursor(new Cursor(Cursor.HAND_CURSOR));
                    }
                }
            }
        });
        
        //Create mouse click
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                if(SwingUtilities.isLeftMouseButton(me)) {
                    if(checkMouseOver(me.getPoint())) {
                        if(cursorChange == true) {
                            setCursor(new Cursor(Cursor.WAIT_CURSOR));
                        }
                    }
                }
            }
        });
    }
    
    public int getTop() {
        return top;
    }
    
    public void setTop(int top) {
        this.top = top;
    }
    
    public int getLeft() {
        return left;
    }
    
    public void setLeft(int left) {
        this.left = left;
    }
    
    public int getBottom() {
        return bottom;
    }
    
    public void setBottom(int bottom) {
        this.bottom = bottom;
    }
    
    public int getRight() {
        return right;
    }
    
    public void setRight(int right) {
        this.right = right;
    }
    
    public int getFontSize() {
        return fontSize;
    }
    
    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }
    
    public int getR() {
        return r;
    }
    
    public void setR(int r) {
        this.r = r;
    }
    
    public int getG() {
        return g;
    }
    
    public void setG(int g) {
        this.g = g;
    }
    
    public int getB() {
        return b;
    }
    
    public void setB(int b) {
        this.b = b;
    }
    
    public boolean getCursorChange() {
        return cursorChange;
    }
    
    public void setCursorChange(boolean cursorChange) {
        this.cursorChange = cursorChange;
    }
    
    @Override
    protected void paintComponent(Graphics grphcs) {
        int x = 0;
        int y = 0;
        int width = getWidth();
        int height = getHeight();
        Graphics2D g2 = (Graphics2D) grphcs.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Area area = new Area(new RoundRectangle2D.Double(x, y, width, height, round, round));
        g2.setColor(new Color(r, g, b));
        g2.fill(area);
        g2.dispose();
        super.paintComponent(grphcs);
    }
    
    private boolean checkMouseOver(Point mouse) {
        int width = getWidth();
        int height = getHeight();
        Point point = new Point();
        Ellipse2D.Double circle = new Ellipse2D.Double(point.x, point.y, width, height);
        return circle.contains(mouse);
    }
}
